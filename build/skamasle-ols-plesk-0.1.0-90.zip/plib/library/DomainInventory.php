<?php

class Modules_SkamasleOls_DomainInventory
{
    const DEFAULT_PAGE_SIZE = 25;
    const MAX_PAGE_SIZE = 100;

    private $lastError;
    private $htaccessScanner;
    private $readiness;
    private $serviceStatus;

    public function __construct(
        $htaccessScanner = null,
        $readiness = null,
        $serviceStatus = null
    )
    {
        $this->htaccessScanner = $htaccessScanner
            ? $htaccessScanner
            : new Modules_SkamasleOls_HtaccessScanner();
        $this->readiness = $readiness
            ? $readiness
            : new Modules_SkamasleOls_DomainReadiness();
        $this->serviceStatus = $serviceStatus
            ? $serviceStatus
            : new Modules_SkamasleOls_SystemServiceStatus();
    }

    public function getSummary($search = '', $page = 1, $pageSize = self::DEFAULT_PAGE_SIZE)
    {
        $this->lastError = null;

        if (!class_exists('pm_Domain')) {
            $this->lastError = 'The Plesk domain API is unavailable.';
            return array();
        }

        try {
            $domains = pm_Domain::getAllDomains();
            $summary = array();
            $server = array(
                'nginx' => $this->serviceStatus->getNginxStatus(),
            );
            $searchTerm = $this->normalizeSearchTerm($search);
            $page = max(1, (int) $page);
            $pageSize = min(self::MAX_PAGE_SIZE, max(1, (int) $pageSize));

            foreach ($domains as $domain) {
                $hasHosting = $domain->hasHosting();
                $item = array(
                    'name' => $domain->getDisplayName(),
                    'guid' => $domain->getGuid(),
                    'active' => $domain->isActive(),
                    'suspended' => $domain->isSuspended(),
                    'hosting' => $hasHosting,
                    'systemUser' => $hasHosting ? $domain->getSysUserLogin() : null,
                    'documentRoot' => $hasHosting ? $domain->getDocumentRoot() : null,
                );
                $htaccess = $hasHosting
                    ? $this->htaccessScanner->scan($item['documentRoot'])
                    : array(
                        'status' => 'blocked',
                        'filesScanned' => 0,
                        'findingCount' => 1,
                        'summary' => array(array(
                            'directive' => 'hosting',
                            'classification' => 'scan-error',
                            'count' => 1,
                            'exampleFile' => '.',
                            'exampleLine' => 0,
                        )),
                        'findings' => array(array(
                            'file' => '.',
                            'line' => 0,
                            'directive' => 'hosting',
                            'classification' => 'scan-error',
                            'message' => 'Physical web hosting is unavailable.',
                        )),
                    );
                $item['htaccess'] = $htaccess;
                $item['readiness'] = $this->readiness->evaluate(
                    $item,
                    $htaccess,
                    $server
                );
                $item['prepared'] = '1' === $domain->getSetting(
                    'skamasle-ols.prepared',
                    '0'
                );
                $item['cacheEnabled'] = '1' === $domain->getSetting(
                    'skamasle-ols.lscache',
                    '0'
                );
                $item['requestedRouting'] = $domain->getSetting(
                    'skamasle-ols.routing',
                    'native'
                );
                if ('' !== $searchTerm && !$this->matchesSearch($item, $searchTerm)) {
                    continue;
                }
                $summary[] = $item;
            }

            $total = count($summary);
            $offset = ($page - 1) * $pageSize;
            $pageItems = array_slice($summary, $offset, $pageSize);
            $pageCount = 0 === $total ? 0 : (int) ceil($total / $pageSize);
            if ($pageCount > 0 && $page > $pageCount) {
                $page = $pageCount;
                $offset = ($page - 1) * $pageSize;
                $pageItems = array_slice($summary, $offset, $pageSize);
            }

            return array(
                'total' => count($domains),
                'filtered' => $total,
                'displayed' => count($pageItems),
                'page' => $page,
                'pageSize' => $pageSize,
                'pages' => $pageCount,
                'search' => $searchTerm,
                'items' => $pageItems,
            );
        } catch (Throwable $exception) {
            $this->lastError = $exception->getMessage();
            error_log(
                '[skamasle-ols] Domain inventory failed: '
                . $exception->getMessage()
            );
            return array();
        }
    }

    public function getLastError()
    {
        return $this->lastError;
    }

    private function normalizeSearchTerm($search)
    {
        $term = strtolower(trim((string) $search));
        return preg_replace('/\s+/', ' ', $term);
    }

    private function matchesSearch(array $domain, $searchTerm)
    {
        $haystack = array(
            isset($domain['name']) ? $domain['name'] : '',
            isset($domain['systemUser']) ? $domain['systemUser'] : '',
            isset($domain['documentRoot']) ? $domain['documentRoot'] : '',
            isset($domain['readiness']['label']) ? $domain['readiness']['label'] : '',
        );
        foreach ($haystack as $value) {
            if ('' !== $value && false !== strpos(strtolower((string) $value), $searchTerm)) {
                return true;
            }
        }

        return false;
    }
}
