<?php

class Modules_SkamasleOls_EnginePackageInstaller
{
    public function install($packageName = 'openlitespeed')
    {
        if (!is_string($packageName) || '' === $packageName) {
            throw new InvalidArgumentException('Package name is required.');
        }

        if (!$this->isRoot()) {
            return array(
                'available' => false,
                'installed' => false,
                'error' => 'Package installation requires root privileges.',
            );
        }

        $packageManager = $this->detectPackageManager();
        if (null === $packageManager) {
            return array(
                'available' => false,
                'installed' => false,
                'error' => 'No supported package manager was found.',
            );
        }

        $repository = $this->ensureRepository();
        if (empty($repository['configured'])) {
            return array(
                'available' => false,
                'installed' => false,
                'packageManager' => $packageManager,
                'packageName' => $packageName,
                'repository' => $repository,
                'error' => isset($repository['error'])
                    ? $repository['error']
                    : 'OpenLiteSpeed repository could not be configured.',
            );
        }

        $alreadyInstalled = $this->runCommand(
            sprintf('rpm -q %s', escapeshellarg($packageName))
        );
        if (0 === $alreadyInstalled['exitCode']) {
            return array(
                'available' => true,
                'installed' => true,
                'packageManager' => $packageManager,
                'packageName' => $packageName,
                'repository' => $repository,
                'exitCode' => 0,
                'output' => $alreadyInstalled['output'],
                'message' => 'Package is already installed.',
            );
        }

        $command = sprintf(
            '%s install -y %s',
            escapeshellcmd($packageManager),
            escapeshellarg($packageName)
        );
        $result = $this->runCommand($command);
        $installed = 0 === $result['exitCode'] && 0 === $this->runCommand(
            sprintf('rpm -q %s', escapeshellarg($packageName))
        )['exitCode'];

        return array(
            'available' => 0 === $result['exitCode'],
            'installed' => $installed,
            'packageManager' => $packageManager,
            'packageName' => $packageName,
            'repository' => $repository,
            'command' => $command,
            'exitCode' => $result['exitCode'],
            'output' => $result['output'],
            'message' => $installed
                ? 'Package installation completed.'
                : 'Package installation failed.',
        );
    }

    protected function ensureRepository()
    {
        if ($this->isRepositoryConfigured()) {
            return array(
                'available' => true,
                'configured' => true,
                'command' => null,
                'exitCode' => 0,
                'output' => 'Repository already configured.',
                'message' => 'LiteSpeed repository already configured.',
            );
        }

        $bootstrapCommand = $this->repositoryBootstrapCommand();
        if (null === $bootstrapCommand) {
            return array(
                'available' => false,
                'configured' => false,
                'error' => 'No repository bootstrap command was found.',
            );
        }

        $result = $this->runCommand($bootstrapCommand);
        $configured = 0 === $result['exitCode'] && $this->isRepositoryConfigured();

        return array(
            'available' => $configured,
            'configured' => $configured,
            'command' => $bootstrapCommand,
            'exitCode' => $result['exitCode'],
            'output' => $result['output'],
            'message' => $configured
                ? 'LiteSpeed repository configured.'
                : 'LiteSpeed repository bootstrap failed.',
        );
    }

    protected function isRepositoryConfigured()
    {
        $litespeedRepo = $this->runCommand(
            'test -f /etc/yum.repos.d/litespeed.repo'
        );
        return 0 === $litespeedRepo['exitCode'];
    }

    protected function repositoryBootstrapCommand()
    {
        $wget = $this->runCommand('command -v wget');
        if (0 === $wget['exitCode'] && '' !== trim($wget['output'])) {
            return 'wget -O - https://repo.litespeed.sh | bash';
        }

        $curl = $this->runCommand('command -v curl');
        if (0 === $curl['exitCode'] && '' !== trim($curl['output'])) {
            return 'curl -fsSL https://repo.litespeed.sh | bash';
        }

        return null;
    }

    protected function detectPackageManager()
    {
        $dnf = $this->runCommand('command -v dnf');
        if (0 === $dnf['exitCode'] && '' !== trim($dnf['output'])) {
            return 'dnf';
        }

        $yum = $this->runCommand('command -v yum');
        if (0 === $yum['exitCode'] && '' !== trim($yum['output'])) {
            return 'yum';
        }

        return null;
    }

    protected function isRoot()
    {
        return function_exists('posix_geteuid')
            ? 0 === posix_geteuid()
            : true;
    }

    protected function runCommand($command)
    {
        $output = array();
        $exitCode = 0;
        exec($command . ' 2>&1', $output, $exitCode);

        return array(
            'exitCode' => (int) $exitCode,
            'output' => implode("\n", $output),
        );
    }
}
